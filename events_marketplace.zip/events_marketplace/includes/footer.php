<footer class="footer">
    <p>&copy; <?php echo date('Y'); ?> Your Event  abcsdd Marketplace</p>
</footer>
